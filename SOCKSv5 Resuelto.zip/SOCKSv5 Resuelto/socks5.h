#ifndef SOCKS5_H_Fu0Ql4AzVLP2XUy2Y3qaQs2dnxo
#define SOCKS5_H_Fu0Ql4AzVLP2XUy2Y3qaQs2dnxo

/**
 * Servidor bloqueante y concurrente socks
 */
int
serve_socks5_concurrent_blocking(const int server);

#endif
