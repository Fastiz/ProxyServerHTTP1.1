#ifndef TEST_H_8VyRIy8mLICCGx62mh19ScMWpkI
#define TEST_H_8VyRIy8mLICCGx62mh19ScMWpkI


#define N(x) (sizeof(x)/sizeof(x[0]))


#endif
